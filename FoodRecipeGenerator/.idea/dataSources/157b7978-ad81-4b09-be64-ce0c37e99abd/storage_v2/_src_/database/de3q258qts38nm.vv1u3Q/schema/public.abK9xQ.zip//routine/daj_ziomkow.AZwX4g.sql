create function daj_ziomkow(my_id integer)
  returns TABLE(so_id integer, nick character varying, age integer, gender character varying)
language plpgsql
as $$
BEGIN
  RETURN QUERY
  SELECT user_id,name, CAST( EXTRACT(YEAR FROM now() )-year_of_birth AS INTEGER ) AS age,sex
  FROM users RIGHT JOIN (
      SELECT
        CAST( SUM(2 - ABS(oceny.moje - oceny.jego) ) AS INTEGER) AS suma,
        jego_id
      FROM
        (
          SELECT
            my.rate      AS moje,
            they.rate    AS jego,
            they.user_id AS jego_id
          FROM ratings AS my LEFT JOIN
            (SELECT *
             FROM ratings) AS they ON
                                     my.dish_id = they.dish_id
          WHERE my.user_id = my_id AND they.user_id <> my_id
                AND my.rate IS NOT NULL
                AND they.rate IS NOT NULL
        ) AS oceny
      GROUP BY oceny.jego_id
      ORDER BY suma  DESC
      LIMIT 10
    ) AS podobni ON user_id=jego_id;
END;
$$;

